InvoiceGen sample data
======================
Every name, number, email and GSTIN in these files is made up.

How to use:
1. Unzip this folder anywhere on your computer.
2. Open InvoiceGen and press "Connect Database".
3. Choose this unzipped folder (InvoiceGen-sample-data).
4. Open Business & Invoice Setup, Customer Details and Item Details to see the examples, then create an invoice.

When you are ready for your own data, create a new empty folder and connect that instead.
