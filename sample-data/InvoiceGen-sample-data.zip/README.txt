InvoiceGen sample data
======================
Everything in this folder is made up: a sample business (Sunrise Traders, with a logo and a signature),
5 customers, 15 items, 5 sellers, 2 bank/UPI entries, a terms set, 5 saved invoices, 2 quotations and 2 drafts.

How to use:
1. Unzip this file: right-click it, choose Extract All, then Extract.
2. Open InvoiceGen. In the welcome window choose "Try it with sample data", then press "Connect sample folder".
   (Or press "Connect Database".)
3. Open the unzipped folder (InvoiceGen-sample-data) and press Select Folder. Allow the app to edit files.
4. Look through Generate Invoice, View All Invoices, Reports, Customer Details and Item Details.
5. When you are done, press "Disconnect sample data" on the yellow bar. The welcome window opens again and you can
   set up your own business in a new, empty folder.

Notes:
- The app knows this is the sample folder from this README.txt file. Keep it in the folder.
- The sample invoices are dated June to November 2026. In Reports, choose "All time" to see all of them.
- Do not use this folder for your real business. Your own data goes in a NEW empty folder.
