InvoiceGen sample data
======================
Everything in this folder is made up: a sample business (Sunrise Traders, with a logo and a signature),
5 customers, 15 items, 5 sellers, 2 bank/UPI entries, a terms set, and 16 sample invoices, quotations and drafts.
It is the same data as "Try it with sample data" inside the app, so every page and report has something to show.

How to use:
1. Unzip this folder anywhere on your computer.
2. Open InvoiceGen and press "Connect Database".
3. Choose this unzipped folder (InvoiceGen-sample-data).
4. Look through Generate Invoice, View All Invoices, Reports, Customer Details and Item Details.

Notes:
- The sample invoices are dated June to November 2026. Reports with "This month" will look empty when you open
  this much later; choose "All time" to see everything. (The in-app "Try it with sample data" button dates them
  from today.)
- Do not use this folder for your real business. When you are ready, create a NEW empty folder and connect that.
